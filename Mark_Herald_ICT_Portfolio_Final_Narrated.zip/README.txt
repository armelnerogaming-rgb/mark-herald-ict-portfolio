Mark Herald V. Cabusas — Empowerment Technologies ICT Portfolio

Open index.html in a browser, or publish the folder to a static host such as Cloudflare Pages.
Video: assets/ict-awareness-video.mp4 (3:37, ElevenLabs narrated, H.264/AAC).
PowerPoint: newtons-laws-presentation.pptx
Keep the assets directory alongside index.html.
Video narrator is synthetic; student should review the content and disclose AI assistance as required by teacher.
